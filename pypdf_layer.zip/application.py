# application.py
from app import app

# Elastic Beanstalk looks for this variable:
application = app